import { NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/db"
import User from "@/models/User"
import { generateOTP } from "@/lib/utils"

export async function POST(request: Request) {
  try {
    // Connect to database
    await connectToDatabase()

    // Get contact info from request body
    const { contactInfo } = await request.json()

    if (!contactInfo) {
      return NextResponse.json({ success: false, message: "Contact information is required" }, { status: 400 })
    }

    // Check if it's an email or phone number
    const isEmail = contactInfo.includes("@")
    const query = isEmail ? { email: contactInfo } : { phone: contactInfo }

    // Generate a 6-digit OTP
    const otp = generateOTP()
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000) // OTP expires in 10 minutes

    // Check if user exists
    const existingUser = await User.findOne(query)
    const userExists = !!existingUser

    if (existingUser) {
      // Update existing user with new OTP
      existingUser.otp = otp
      existingUser.otpExpiresAt = otpExpiresAt
      await existingUser.save()
    } else {
      // Create a new user with just the contact info and OTP
      const newUser = new User({
        ...(isEmail ? { email: contactInfo } : { phone: contactInfo }),
        otp,
        otpExpiresAt,
        isVerified: false,
      })
      await newUser.save()
    }

    // In a real application, you would send the OTP via SMS or email here
    // For development, we'll just return it in the response
    return NextResponse.json({
      success: true,
      message: "OTP sent successfully",
      userExists,
      // Only include OTP in development
      ...(process.env.NODE_ENV === "development" && { otp }),
    })
  } catch (error) {
    console.error("Error sending OTP:", error)
    return NextResponse.json({ success: false, message: "Failed to send OTP" }, { status: 500 })
  }
}
