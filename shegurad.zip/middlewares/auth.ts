import { verifyToken } from "@/lib/auth"
import User from "@/models/User"
import { connectToDatabase } from "@/lib/db"

/**
 * Authentication middleware for API routes
 * @param request Next.js request object
 * @returns User object if authenticated, null otherwise
 */
export async function authMiddleware(request: Request) {
  try {
    // Connect to database
    await connectToDatabase()

    // Get auth token from cookies
    const authToken = request.cookies.get("auth_token")?.value

    if (!authToken) {
      return null
    }

    // Verify token and get user ID
    const userId = verifyToken(authToken)
    if (!userId) {
      return null
    }

    // Find user by ID
    const user = await User.findById(userId)
    if (!user) {
      return null
    }

    return user
  } catch (error) {
    console.error("Auth middleware error:", error)
    return null
  }
}
